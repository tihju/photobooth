
portNum = 10316;

function getMainPage() {
  window.location.href = "http://138.68.25.50:" + portNum + "/photoboothMain.html";
}
