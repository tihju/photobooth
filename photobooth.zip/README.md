# ECS189H - Assignment 1 Photobooth Part One

### Group Members:
- Man Yu Mandy Wong
- Chi Kei Loi
- Tingting Zhu
